package com.grandtool.app

import android.content.Context
import android.content.res.Resources
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.Button

object Ui {
    val BG = 0xFF0E1015.toInt()
    val CARD = 0xFF181B23.toInt()
    val ACCENT = 0xFF00E5A8.toInt()
    val TEXT = 0xFFE6E8EE.toInt()
    val MUTED = 0xFF8A91A0.toInt()

    val density: Float get() = Resources.getSystem().displayMetrics.density
    fun dp(v: Int): Int = (v * density).toInt()

    fun round(color: Int, radiusDp: Int = 12) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusDp * density
    }

    fun button(ctx: Context, text: String, color: Int = 0xFF2A3040.toInt(), onClick: () -> Unit) =
        Button(ctx).apply {
            this.text = text
            isAllCaps = false
            textSize = 14f
            setTextColor(Color.WHITE)
            background = round(color)
            setOnClickListener { onClick() }
        }
}

/** Кнопка ON/OFF, привязанная к булевой настройке. */
class Toggle(
    ctx: Context,
    private val name: String,
    private val get: () -> Boolean,
    private val set: (Boolean) -> Unit
) : Button(ctx) {
    init {
        isAllCaps = false
        textSize = 14f
        setTextColor(Color.WHITE)
        setOnClickListener { set(!get()); Prefs.save(); refresh() }
        refresh()
    }

    fun refresh() {
        text = "$name: ${if (get()) "ON" else "OFF"}"
        background = Ui.round(if (get()) 0xFF1B8F4B.toInt() else 0xFF3A3F4B.toInt())
    }
}
