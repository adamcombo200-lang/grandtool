package com.grandtool.app

import android.content.Context
import android.content.SharedPreferences

/** Все настройки и статистика. Хранятся в памяти и сохраняются в SharedPreferences. */
object Prefs {
    private lateinit var sp: SharedPreferences

    var fpsOn = true
    var espOn = true
    var aimOn = false
    var shootOn = false
    var sensitivity = 50      // 1..100
    var crosshair = 40        // 16..120 (dp)

    var hits = 0
    var shots = 0
    var kills = 0
    var bestStreak = 0

    val accuracy: Int get() = if (shots == 0) 0 else hits * 100 / shots

    fun init(c: Context) {
        if (::sp.isInitialized) return
        sp = c.applicationContext.getSharedPreferences("grand_tool", Context.MODE_PRIVATE)
        fpsOn = sp.getBoolean("fpsOn", true)
        espOn = sp.getBoolean("espOn", true)
        aimOn = sp.getBoolean("aimOn", false)
        shootOn = sp.getBoolean("shootOn", false)
        sensitivity = sp.getInt("sens", 50)
        crosshair = sp.getInt("cross", 40)
        hits = sp.getInt("hits", 0)
        shots = sp.getInt("shots", 0)
        kills = sp.getInt("kills", 0)
        bestStreak = sp.getInt("best", 0)
    }

    fun save() {
        if (!::sp.isInitialized) return
        sp.edit()
            .putBoolean("fpsOn", fpsOn).putBoolean("espOn", espOn)
            .putBoolean("aimOn", aimOn).putBoolean("shootOn", shootOn)
            .putInt("sens", sensitivity).putInt("cross", crosshair)
            .putInt("hits", hits).putInt("shots", shots)
            .putInt("kills", kills).putInt("best", bestStreak)
            .apply()
    }

    fun resetStats() {
        hits = 0; shots = 0; kills = 0; bestStreak = 0
        save()
    }

    fun statsLine() =
        "Попадания: $hits   Выстрелы: $shots\nТочность: $accuracy%   Убито: $kills   Лучшая серия: $bestStreak"
}
