package com.grandtool.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** Плавающее меню поверх экрана (нужно разрешение «Поверх других приложений»). */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var root: View? = null
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var fpsText: TextView
    private lateinit var statsText: TextView
    private val toggles = ArrayList<Toggle>()

    private var frames = 0
    private var fpsT = 0L

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            frames++
            if (fpsT == 0L) fpsT = t
            if (t - fpsT >= 1_000_000_000L) {
                fpsText.text = if (Prefs.fpsOn) "FPS: $frames" else "FPS: —"
                statsText.text = "Hits ${Prefs.hits} | Acc ${Prefs.accuracy}%"
                toggles.forEach { it.refresh() }
                frames = 0; fpsT = t
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Prefs.init(this)
        startAsForeground()
        if (root == null) {
            build()
            Choreographer.getInstance().postFrameCallback(frameCb)
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val ch = "grand_tool_overlay"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "GRAND TOOL", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("GRAND TOOL")
            .setContentText("Плавающее меню активно")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun label(text: String, size: Float, color: Int) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
    }

    private fun build() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(0xEE12151C.toInt(), 14)
            setPadding(Ui.dp(10), Ui.dp(8), Ui.dp(10), Ui.dp(10))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = label("GRAND TOOL", 14f, Ui.ACCENT).apply { typeface = Typeface.DEFAULT_BOLD }
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val minBtn = label("  —  ", 16f, Ui.TEXT).apply {
            setOnClickListener { body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        }
        val closeBtn = label("  ✕  ", 16f, 0xFFFF6B6B.toInt()).apply { setOnClickListener { stopSelf() } }
        header.addView(minBtn)
        header.addView(closeBtn)

        fpsText = label("FPS: …", 13f, Ui.TEXT)
        statsText = label("Hits 0 | Acc 0%", 12f, Ui.MUTED)
        body.addView(fpsText)
        body.addView(statsText)

        fun addToggle(name: String, get: () -> Boolean, set: (Boolean) -> Unit) {
            val t = Toggle(this, name, get, set)
            toggles.add(t)
            val lpb = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(44))
            lpb.topMargin = Ui.dp(6)
            body.addView(t, lpb)
        }
        addToggle("FPS монитор", { Prefs.fpsOn }, { Prefs.fpsOn = it })
        addToggle("ESP рамки", { Prefs.espOn }, { Prefs.espOn = it })
        addToggle("Автонаведение", { Prefs.aimOn }, { Prefs.aimOn = it })
        addToggle("Auto Shoot", { Prefs.shootOn }, { Prefs.shootOn = it })

        panel.addView(header)
        panel.addView(body)

        lp = WindowManager.LayoutParams(
            Ui.dp(210), ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = Ui.dp(12); y = Ui.dp(120) }

        // перетаскивание за заголовок
        header.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = sx + (e.rawX - tx).toInt()
                        lp.y = sy + (e.rawY - ty).toInt()
                        wm.updateViewLayout(panel, lp)
                    }
                }
                return true
            }
        })

        wm.addView(panel, lp)
        root = panel
    }

    override fun onDestroy() {
        Choreographer.getInstance().removeFrameCallback(frameCb)
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        Prefs.save()
        super.onDestroy()
    }
}
