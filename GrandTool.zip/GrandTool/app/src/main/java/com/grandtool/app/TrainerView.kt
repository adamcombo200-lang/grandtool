package com.grandtool.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import java.util.Random
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Собственная тестовая сцена: движущиеся боты-мишени, ESP-рамки,
 * автонаведение (тренажёр), Auto Shoot, FPS и статистика.
 * Работает только внутри этого View и ничего не трогает в других приложениях.
 */
class TrainerView(ctx: Context) : View(ctx) {

    private class Bot(
        var x: Float, var y: Float, var vx: Float, var vy: Float,
        val w: Float, val h: Float, var hp: Int, val name: String
    ) {
        val maxHp = hp
        val aimX get() = x + w / 2
        val aimY get() = y + h * 0.3f
    }

    private val bots = ArrayList<Bot>()
    private val rnd = Random()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    private var cx = 0f
    private var cy = 0f
    private var lastT = 0L
    private var fps = 0
    private var frames = 0
    private var fpsT = 0L
    private var cooldown = 0f
    private var flash = 0f
    private var streak = 0
    private var botId = 1
    private var running = false

    private var lx = 0f
    private var ly = 0f
    private var downT = 0L
    private var moved = 0f

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            if (!running) return
            step(t)
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        lastT = 0L
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    override fun onDetachedFromWindow() {
        running = false
        Choreographer.getInstance().removeFrameCallback(frameCb)
        Prefs.save()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cx = w / 2f; cy = h / 2f
        bots.clear()
        repeat(4) { spawn() }
    }

    private fun spawn() {
        val d = Ui.density
        val w = (34 + rnd.nextInt(18)) * d
        val h = w * 1.9f
        val top = height * 0.12f
        val x = rnd.nextFloat() * (width - w).coerceAtLeast(1f)
        val y = top + rnd.nextFloat() * (height - h - top).coerceAtLeast(1f)
        var vx = (60 + rnd.nextInt(110)) * d
        if (rnd.nextBoolean()) vx = -vx
        val vy = (rnd.nextFloat() - 0.5f) * 80 * d
        bots.add(Bot(x, y, vx, vy, w, h, 3, "BOT-${botId++}"))
    }

    private fun botUnderCrosshair(): Bot? {
        val tol = Prefs.crosshair * Ui.density * 0.1f
        return bots.firstOrNull {
            cx >= it.x - tol && cx <= it.x + it.w + tol && cy >= it.y - tol && cy <= it.y + it.h + tol
        }
    }

    private fun fire() {
        Prefs.shots++
        val b = botUnderCrosshair()
        if (b != null) {
            Prefs.hits++
            streak++
            if (streak > Prefs.bestStreak) Prefs.bestStreak = streak
            flash = 0.15f
            b.hp--
            if (b.hp <= 0) {
                Prefs.kills++
                bots.remove(b)
                spawn()
            }
        } else {
            streak = 0
        }
        Prefs.save()
    }

    private fun step(t: Long) {
        val dt = if (lastT == 0L) 0.016f else ((t - lastT) / 1e9f).coerceAtMost(0.05f)
        lastT = t
        frames++
        if (fpsT == 0L) fpsT = t
        if (t - fpsT >= 1_000_000_000L) { fps = frames; frames = 0; fpsT = t }

        val top = height * 0.12f
        for (b in bots) {
            b.x += b.vx * dt
            b.y += b.vy * dt
            if (b.x < 0) { b.x = 0f; b.vx = -b.vx }
            if (b.x + b.w > width) { b.x = width - b.w; b.vx = -b.vx }
            if (b.y < top) { b.y = top; b.vy = -b.vy }
            if (b.y + b.h > height) { b.y = height - b.h; b.vy = -b.vy }
        }

        // Автонаведение (тренажёр): прицел плавно летит к ближайшей мишени
        if (Prefs.aimOn && bots.isNotEmpty()) {
            val target = bots.minByOrNull { hypot(it.aimX - cx, it.aimY - cy) }!!
            val dx = target.aimX - cx
            val dy = target.aimY - cy
            val dist = hypot(dx, dy)
            val speed = (150 + Prefs.sensitivity * 12) * Ui.density * dt
            if (dist <= speed) { cx = target.aimX; cy = target.aimY }
            else { cx += dx / dist * speed; cy += dy / dist * speed }
        }

        // Auto Shoot: стреляет сам, когда прицел на мишени
        cooldown -= dt
        if (Prefs.shootOn && cooldown <= 0f && botUnderCrosshair() != null) {
            fire()
            cooldown = 0.2f
        }
        if (flash > 0) flash -= dt
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        val d = Ui.density
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y; downT = e.eventTime; moved = 0f }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lx
                val dy = e.y - ly
                moved += abs(dx) + abs(dy)
                lx = e.x; ly = e.y
                if (!Prefs.aimOn) {
                    val k = 0.5f + Prefs.sensitivity / 50f
                    cx = (cx + dx * k).coerceIn(0f, width.toFloat())
                    cy = (cy + dy * k).coerceIn(0f, height.toFloat())
                }
            }
            MotionEvent.ACTION_UP -> {
                if (moved < 20 * d && e.eventTime - downT < 300) fire()
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val d = Ui.density
        c.drawColor(0xFF0B0D12.toInt())

        // сетка
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = 0xFF1A1F2B.toInt()
        var g = 0f
        while (g < width) { c.drawLine(g, 0f, g, height.toFloat(), p); g += 40 * d }
        g = 0f
        while (g < height) { c.drawLine(0f, g, width.toFloat(), g, p); g += 40 * d }

        for (b in bots) drawBot(c, b, d)

        // прицел
        val s = Prefs.crosshair * d
        val gap = s * 0.25f
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.5f * d
        p.color = if (flash > 0) 0xFFFF4D4D.toInt() else 0xFFFFFFFF.toInt()
        c.drawLine(cx - s, cy, cx - gap, cy, p)
        c.drawLine(cx + gap, cy, cx + s, cy, p)
        c.drawLine(cx, cy - s, cx, cy - gap, p)
        c.drawLine(cx, cy + gap, cx, cy + s, p)
        c.drawCircle(cx, cy, s * 0.6f, p)
        p.style = Paint.Style.FILL
        c.drawCircle(cx, cy, 2.5f * d, p)

        // HUD
        p.style = Paint.Style.FILL
        p.textSize = 13 * d
        p.textAlign = Paint.Align.LEFT
        if (Prefs.fpsOn) {
            p.color = if (fps >= 55) 0xFF00E5A8.toInt() else if (fps >= 30) 0xFFFFC857.toInt() else 0xFFFF4D4D.toInt()
            c.drawText("FPS: $fps", 10 * d, 20 * d, p)
        }
        p.color = Ui.TEXT
        p.textAlign = Paint.Align.RIGHT
        c.drawText("Hits ${Prefs.hits} | Acc ${Prefs.accuracy}% | Streak $streak", width - 10 * d, 20 * d, p)
        p.textAlign = Paint.Align.LEFT
        p.color = Ui.MUTED
        p.textSize = 11 * d
        c.drawText(
            "AIM:${if (Prefs.aimOn) "ON" else "OFF"}  SHOOT:${if (Prefs.shootOn) "ON" else "OFF"}  ESP:${if (Prefs.espOn) "ON" else "OFF"}",
            10 * d, height - 10 * d, p
        )
    }

    private fun drawBot(c: Canvas, b: Bot, d: Float) {
        // тело бота
        p.style = Paint.Style.FILL
        p.color = 0xFF3B4252.toInt()
        rect.set(b.x, b.y + b.w * 0.5f, b.x + b.w, b.y + b.h)
        c.drawRoundRect(rect, 6 * d, 6 * d, p)
        p.color = 0xFF5B6478.toInt()
        c.drawCircle(b.x + b.w / 2, b.y + b.w * 0.27f, b.w * 0.24f, p)

        if (!Prefs.espOn) return

        // ESP: рамка, имя, дистанция, полоска HP, линия
        val pad = 4 * d
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2 * d
        p.color = 0xFF00FF7F.toInt()
        rect.set(b.x - pad, b.y - pad, b.x + b.w + pad, b.y + b.h + pad)
        c.drawRect(rect, p)

        p.strokeWidth = 1f
        p.alpha = 90
        c.drawLine(width / 2f, height.toFloat(), b.x + b.w / 2, b.y + b.h + pad, p)
        p.alpha = 255

        val dist = hypot(b.aimX - width / 2f, b.aimY - height.toFloat()) / d / 10f
        p.style = Paint.Style.FILL
        p.textSize = 10 * d
        p.textAlign = Paint.Align.CENTER
        p.color = 0xFF00FF7F.toInt()
        c.drawText("${b.name}  ${"%.0f".format(dist)}m", b.x + b.w / 2, b.y - pad - 3 * d, p)

        val frac = b.hp.toFloat() / b.maxHp
        val bx = b.x - pad - 5 * d
        p.color = 0xFF222733.toInt()
        c.drawRect(bx, b.y - pad, bx + 3 * d, b.y + b.h + pad, p)
        p.color = if (frac > 0.5f) 0xFF00E56B.toInt() else if (frac > 0.3f) 0xFFFFC857.toInt() else 0xFFFF4D4D.toInt()
        val full = b.h + 2 * pad
        c.drawRect(bx, b.y + b.h + pad - full * frac, bx + 3 * d, b.y + b.h + pad, p)
        p.textAlign = Paint.Align.LEFT
    }
}
