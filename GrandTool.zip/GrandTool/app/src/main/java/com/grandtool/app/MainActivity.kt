package com.grandtool.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private val refreshers = ArrayList<() -> Unit>()
    private lateinit var stats: TextView

    private val tick = object : Runnable {
        override fun run() {
            stats.text = Prefs.statsLine()
            refreshers.forEach { it() }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(16), Ui.dp(16), Ui.dp(16), Ui.dp(28))
        }
        val scroll = ScrollView(this).apply { setBackgroundColor(Ui.BG); addView(col) }

        fun text(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        fun lp(h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, top: Int = 8) =
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h).apply { topMargin = Ui.dp(top) }

        col.addView(text("GRAND TOOL", 28f, Ui.ACCENT, true))
        col.addView(text("Тренажёр прицеливания · тестовая сцена", 13f, Ui.MUTED))

        col.addView(Ui.button(this, "Запустить плавающее меню", 0xFF1B6FE0.toInt()) { startOverlay() }, lp(Ui.dp(48), 14))
        col.addView(Ui.button(this, "Остановить плавающее меню") {
            stopService(Intent(this, OverlayService::class.java))
        }, lp(Ui.dp(44)))

        col.addView(text("Тестовая сцена (тяни — двигай прицел, тап — выстрел)", 12f, Ui.MUTED), lp(top = 16))
        col.addView(TrainerView(this), lp(Ui.dp(420), 6))

        fun addToggle(name: String, get: () -> Boolean, set: (Boolean) -> Unit) {
            val t = Toggle(this, name, get, set)
            refreshers.add { t.refresh() }
            col.addView(t, lp(Ui.dp(46)))
        }
        addToggle("FPS монитор", { Prefs.fpsOn }, { Prefs.fpsOn = it })
        addToggle("ESP рамки", { Prefs.espOn }, { Prefs.espOn = it })
        addToggle("Автонаведение", { Prefs.aimOn }, { Prefs.aimOn = it })
        addToggle("Auto Shoot", { Prefs.shootOn }, { Prefs.shootOn = it })

        fun slider(name: String, min: Int, max: Int, get: () -> Int, set: (Int) -> Unit) {
            val label = text("", 14f, Ui.TEXT)
            fun upd() { label.text = "$name: ${get()}" }
            upd()
            val sb = SeekBar(this).apply {
                this.max = max - min
                progress = get() - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        set(p + min); upd()
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) { Prefs.save() }
                })
            }
            col.addView(label, lp(top = 14))
            col.addView(sb, lp(top = 2))
        }
        slider("Чувствительность", 1, 100, { Prefs.sensitivity }, { Prefs.sensitivity = it })
        slider("Размер прицела", 16, 120, { Prefs.crosshair }, { Prefs.crosshair = it })

        col.addView(text("Статистика", 16f, Ui.ACCENT, true), lp(top = 18))
        stats = text(Prefs.statsLine(), 14f, Ui.TEXT).apply {
            background = Ui.round(Ui.CARD); setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(12), Ui.dp(10))
        }
        col.addView(stats, lp(top = 6))
        col.addView(Ui.button(this, "Сбросить статистику", 0xFF7A2B2B.toInt()) {
            Prefs.resetStats(); Toast.makeText(this, "Статистика сброшена", Toast.LENGTH_SHORT).show()
        }, lp(Ui.dp(44), 10))

        setContentView(scroll)
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Включи «Поверх других приложений» для GRAND TOOL и вернись назад", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "Меню запущено — сверни приложение", Toast.LENGTH_SHORT).show()
    }

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { handler.removeCallbacks(tick); Prefs.save(); super.onPause() }
}
