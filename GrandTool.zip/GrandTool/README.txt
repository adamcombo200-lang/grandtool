GRAND TOOL - Android (Kotlin). Тренажёр прицеливания в собственной тестовой сцене.
Сборка: см. инструкцию в чате (GitHub Actions) или открыть папку в Android Studio / AndroidIDE.
